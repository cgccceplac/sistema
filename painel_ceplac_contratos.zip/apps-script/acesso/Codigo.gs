/**
 * LOGIN DO PAINEL CEPLAC (código de 6 dígitos por e-mail)
 * ------------------------------------------------------------------
 * Onde colar: num projeto do Apps Script ligado a uma planilha Google
 * (Extensões › Apps Script, na planilha "ACESSO PAINEL CEPLAC").
 *
 * A planilha precisa de duas abas:
 *   USUARIOS     → colunas: Email | Nome | Unidade | Ativo (SIM/NAO)
 *   SOLICITACOES → criada sozinha no primeiro pedido de acesso
 *
 * Publicar: Implantar › Nova implantação › App da Web
 *   Executar como: Eu  ·  Quem pode acessar: Qualquer pessoa
 * Copie o link /exec e cole em URL_ACESSO no docs/index.html.
 */

var DOMINIOS = ['agro.gov.br'];              // e-mails aceitos
var EMAIL_ADMIN = 'cgcc.ceplac@agro.gov.br'; // recebe os pedidos de acesso
var MIN_CODIGO = 10;                         // validade do código (minutos)
var DIAS_TOKEN = 60;                         // "manter conectado"
var MAX_TENTATIVAS = 5;

function doGet(e) {
  var p = (e && e.parameter) || {};
  var r;
  try {
    switch (p.acao) {
      case 'pedir': r = pedir_(p.email); break;
      case 'validar': r = validar_(p.email, p.codigo, p.manter === '1'); break;
      case 'verificar': r = verificar_(p.token); break;
      case 'solicitar': r = solicitar_(p.nome, p.email, p.unidade); break;
      case 'sair': r = sair_(p.token); break;
      default: r = {ok: false, erro: 'Ação desconhecida.'};
    }
  } catch (err) {
    r = {ok: false, erro: 'Erro no serviço de acesso. Tente de novo.'};
    console.error(err);
  }
  return ContentService.createTextOutput(JSON.stringify(r)).setMimeType(ContentService.MimeType.JSON);
}

function normalizar_(email) { return String(email || '').trim().toLowerCase(); }

function dominioOk_(email) {
  var d = email.split('@')[1] || '';
  return DOMINIOS.indexOf(d) >= 0;
}

function usuario_(email) {
  var aba = SpreadsheetApp.getActive().getSheetByName('USUARIOS');
  if (!aba) throw new Error('Aba USUARIOS não existe.');
  var linhas = aba.getDataRange().getValues();
  for (var i = 1; i < linhas.length; i++) {
    if (normalizar_(linhas[i][0]) === email) {
      return {email: email, nome: linhas[i][1], unidade: linhas[i][2], ativo: String(linhas[i][3]).toUpperCase() === 'SIM'};
    }
  }
  return null;
}

function pedir_(email) {
  email = normalizar_(email);
  if (!dominioOk_(email)) return {ok: false, erro: 'Use o e-mail institucional (@' + DOMINIOS.join(', @') + ').'};
  var u = usuario_(email);
  if (!u || !u.ativo) return {ok: false, erro: 'Este e-mail não tem acesso liberado. Use "Solicitar acesso".'};
  var codigo = String(Math.floor(100000 + Math.random() * 900000));
  CacheService.getScriptCache().put('cod_' + email, JSON.stringify({c: codigo, t: 0}), MIN_CODIGO * 60);
  MailApp.sendEmail({
    to: email,
    subject: 'Painel CEPLAC · seu código de acesso: ' + codigo,
    body: 'Olá' + (u.nome ? ', ' + u.nome : '') + '.\n\nSeu código de acesso ao Painel CEPLAC é: ' + codigo +
          '\n\nEle vale por ' + MIN_CODIGO + ' minutos. Se você não pediu este código, ignore este e-mail.\n\nCGCC/CEPLAC'
  });
  return {ok: true};
}

function validar_(email, codigo, manter) {
  email = normalizar_(email);
  var cache = CacheService.getScriptCache();
  var bruto = cache.get('cod_' + email);
  if (!bruto) return {ok: false, erro: 'Código expirado. Peça um novo.'};
  var reg = JSON.parse(bruto);
  if (reg.t >= MAX_TENTATIVAS) { cache.remove('cod_' + email); return {ok: false, erro: 'Muitas tentativas. Peça um novo código.'}; }
  if (String(codigo) !== reg.c) {
    reg.t++;
    cache.put('cod_' + email, JSON.stringify(reg), MIN_CODIGO * 60);
    return {ok: false, erro: 'Código incorreto. Restam ' + (MAX_TENTATIVAS - reg.t) + ' tentativa(s).'};
  }
  cache.remove('cod_' + email);
  var token = Utilities.getUuid() + Utilities.getUuid().replace(/-/g, '');
  var dias = manter ? DIAS_TOKEN : 1;
  PropertiesService.getScriptProperties().setProperty('tok_' + token, JSON.stringify({e: email, x: Date.now() + dias * 86400000}));
  return {ok: true, token: token, email: email};
}

function verificar_(token) {
  if (!token) return {ok: false};
  var props = PropertiesService.getScriptProperties();
  var bruto = props.getProperty('tok_' + token);
  if (!bruto) return {ok: false};
  var reg = JSON.parse(bruto);
  var u = usuario_(reg.e);
  if (reg.x < Date.now() || !u || !u.ativo) { props.deleteProperty('tok_' + token); return {ok: false}; }
  return {ok: true, email: reg.e};
}

function sair_(token) {
  if (token) PropertiesService.getScriptProperties().deleteProperty('tok_' + token);
  return {ok: true};
}

function solicitar_(nome, email, unidade) {
  email = normalizar_(email);
  if (!nome || !unidade) return {ok: false, erro: 'Preencha nome e unidade.'};
  if (!dominioOk_(email)) return {ok: false, erro: 'Use o e-mail institucional (@' + DOMINIOS.join(', @') + ').'};
  var ss = SpreadsheetApp.getActive();
  var aba = ss.getSheetByName('SOLICITACOES') || ss.insertSheet('SOLICITACOES');
  if (aba.getLastRow() === 0) aba.appendRow(['Data', 'Nome', 'Email', 'Unidade', 'Situação']);
  aba.appendRow([new Date(), String(nome).slice(0, 120), email, String(unidade).slice(0, 120), 'PENDENTE']);
  MailApp.sendEmail(EMAIL_ADMIN, 'Painel CEPLAC · pedido de acesso de ' + nome,
    nome + ' (' + email + ', ' + unidade + ') pediu acesso ao Painel CEPLAC.\n\n' +
    'Para liberar: inclua o e-mail na aba USUARIOS da planilha com "SIM" na coluna Ativo.\n' + ss.getUrl());
  return {ok: true};
}

/** Rodar 1x por semana (Acionadores › por tempo) para apagar tokens vencidos. */
function limparTokens() {
  var props = PropertiesService.getScriptProperties();
  var todos = props.getProperties();
  Object.keys(todos).forEach(function (k) {
    if (k.indexOf('tok_') === 0) {
      try { if (JSON.parse(todos[k]).x < Date.now()) props.deleteProperty(k); } catch (e) { props.deleteProperty(k); }
    }
  });
}
