# Painel CEPLAC · Contratos

Painel dos contratos das UGs da CEPLAC, com dados públicos do **Contratos.gov.br**.
Inspirado no Painel SDR (painel-sdr/transferegov-sdr), adaptado para a CEPLAC/CGCC.

## Como funciona

| Peça | Onde fica | O que faz |
|---|---|---|
| Robô | `scripts/contratos_ceplac.py` + `.github/workflows/atualizar.yml` | De segunda a sexta, às 6h23, baixa os contratos das UGs de `config/ugs.json` e grava `contratos.json` na branch **dados** |
| Painel | `docs/index.html` (GitHub Pages) | Lê o `contratos.json` e mostra os indicadores, as barras por UG, a tabela e a ficha de cada contrato |
| Login | `apps-script/acesso/Codigo.gs` (Google Apps Script) | Envia o código de 6 dígitos por e-mail e confere a lista de usuários na planilha |

## Primeira configuração

1. **Ligar o GitHub Pages:** Settings › Pages › Source: *Deploy from a branch* › Branch `main`, pasta `/docs` › Save.
2. **Rodar o robô na primeira vez:** Actions › *Atualizar contratos CEPLAC* › Run workflow. Depois ele roda sozinho.
3. **Login (opcional):** crie a planilha "ACESSO PAINEL CEPLAC" com a aba `USUARIOS`
   (Email | Nome | Unidade | Ativo), cole o `Codigo.gs` no Apps Script dela, publique como App da Web
   e cole o link `/exec` em `URL_ACESSO`, no início do script do `docs/index.html`.
   Com `URL_ACESSO` vazio, o painel abre sem login.

## Incluir ou tirar UG

Edite `config/ugs.json`. O campo `rotulo` é opcional: se ficar vazio, o painel usa o nome da UG que vem da API.

## Importante

- O repositório é **público** (necessário para o GitHub Pages gratuito). Só entram dados que já são públicos no Contratos.gov.br.
  **Não suba planilhas internas, dados de servidores nem senhas.**
- O login protege a tela do painel; o arquivo `contratos.json` da branch `dados` continua acessível a quem tiver o link, como os próprios dados do Contratos.gov.br.
- CPF de pessoas físicas é mascarado (LGPD) antes de gravar.
