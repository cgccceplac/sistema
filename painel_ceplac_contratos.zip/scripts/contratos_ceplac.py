"""Contratos da CEPLAC no Contratos.gov.br (API pública https://contratos.comprasnet.gov.br/api).

Lê as UGs de config/ugs.json, baixa os contratos ativos e inativos de cada UG e, para os ativos,
os detalhes (termos aditivos, empenhos, faturas, responsáveis, itens e arquivos).
Grava PASTA/contratos.json, o arquivo que o painel (docs/index.html) lê.

Se a API falhar, mantém o arquivo da rodada anterior (variável CONTRATOS_ANTERIOR).
LGPD: CPF de pessoa física é mascarado (***.123.456-**) antes de gravar.

Uso: python scripts/contratos_ceplac.py PASTA_SAIDA
"""
import json
import os
import re
import shutil
import sys
import time
import urllib.error
import urllib.request
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timedelta, timezone

BASE = 'https://contratos.comprasnet.gov.br'
RAIZ = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OUT = sys.argv[1] if len(sys.argv) > 1 else 'saida'
ANT = os.environ.get('CONTRATOS_ANTERIOR', '')
BRT = timezone(timedelta(hours=-3))
DETALHES = ['historico', 'empenhos', 'faturas', 'responsaveis', 'itens', 'arquivos']

CPF = re.compile(r'(?<![\d./-])(\d{3})\.?(\d{3})\.?(\d{3})-?(\d{2})(?!\d|[.,]\d)')


def mascara(s):
    if not isinstance(s, str) or len(s) < 11:
        return s
    return CPF.sub(lambda m: f'***.{m.group(2)}.{m.group(3)}-**', s)


def get(caminho):
    """GET na API com 4 tentativas. 400/401/404 = sem dados (devolve None)."""
    url = BASE + caminho
    erro = ''
    for t in range(4):
        try:
            req = urllib.request.Request(url, headers={'Accept': 'application/json', 'User-Agent': 'painel-ceplac/1.0'})
            with urllib.request.urlopen(req, timeout=90) as r:
                return json.loads(r.read())
        except urllib.error.HTTPError as e:
            if e.code in (400, 401, 404):
                return None
            erro = f'HTTP {e.code}'
        except Exception as e:  # rede, timeout, JSON inválido
            erro = f'{type(e).__name__}: {e}'
        time.sleep(5 * (t + 1))
    raise RuntimeError(f'falhou: {url} ({erro})')


def lista(x):
    return x if isinstance(x, list) else []


def txt(v, limite=None):
    s = '' if v is None or str(v) in ('None', 'null') else str(v).strip()
    return s[:limite] if limite else s


def num(v):
    """Aceita 1234.56, '1234.56' e '1.234,56'."""
    s = txt(v)
    if not s:
        return 0.0
    try:
        return float(s.replace('.', '').replace(',', '.')) if ',' in s else float(s)
    except ValueError:
        return 0.0


def data(v):
    """2026-03-31 ou 2026-03-31T00:00:00 -> 2026-03-31 (o painel formata em dd/mm/aaaa)."""
    m = re.match(r'(\d{4}-\d{2}-\d{2})', txt(v))
    return m.group(1) if m else ''


def ug_info(c):
    o = ((c.get('contratante') or {}).get('orgao_origem') or {}).get('unidade_gestora_origem') or {}
    if not o:
        o = ((c.get('contratante') or {}).get('orgao') or {}).get('unidade_gestora') or {}
    return txt(o.get('codigo')), txt(o.get('nome_resumido') or o.get('nome'))


def detalhes(c):
    i = c['id']
    d = {}
    for k in DETALHES:
        try:
            d[k] = lista(get(f'/api/contrato/{i}/{k}'))
        except RuntimeError as e:
            print(f'  contrato {i}: {k} não veio ({e})', flush=True)
            d[k] = []
    return c, d


def montar(c, d, ug, rotulos):
    forn = c.get('fornecedor') or {}
    ug_orig, ug_nome = ug_info(c)
    reg = {
        'id': c.get('id'),
        'ug': ug,
        'ugNome': rotulos.get(ug) or ug_nome,
        'ugOrigem': ug_orig,
        'num': txt(c.get('numero')),
        'tipo': txt(c.get('tipo')),
        'cat': txt(c.get('categoria')),
        'mod': txt(c.get('modalidade')),
        'sit': txt(c.get('situacao')),
        'ativo': bool(c.get('_ativo')),
        'forn': txt(forn.get('nome')),
        'doc': mascara(txt(forn.get('cnpj_cpf_idgener'))),
        'proc': txt(c.get('processo')),
        'obj': txt(c.get('objeto'), 1500),
        'ini': data(c.get('vigencia_inicio')),
        'fim': data(c.get('vigencia_fim')),
        'vIni': num(c.get('valor_inicial')),
        'vGlob': num(c.get('valor_global')),
        'vAcum': num(c.get('valor_acumulado')),
        'nParc': txt(c.get('num_parcelas')),
        'vParc': num(c.get('valor_parcela')),
        'link': f"{BASE}/transparencia/contratos/{c.get('id')}",
    }
    if not d:
        return reg
    reg['his'] = [{'tipo': txt(h.get('tipo')), 'num': txt(h.get('numero')), 'ass': data(h.get('data_assinatura')),
                   'fim': data(h.get('vigencia_fim')), 'valor': num(h.get('novo_valor_global') or h.get('valor_global')),
                   'obs': txt(h.get('observacao'), 400)}
                  for h in sorted(d['historico'], key=lambda h: txt(h.get('data_assinatura')))]
    reg['emp'] = [{'ne': txt(e.get('numero')), 'ug': txt(e.get('unidade_gestora')), 'pi': txt(e.get('planointerno'), 60),
                   'data': data(e.get('data_emissao'))} for e in d['empenhos']]
    reg['fat'] = [{'num': txt(f.get('numero')), 'emi': data(f.get('emissao')), 'venc': data(f.get('vencimento')),
                   'valor': round(num(f.get('valor')) - num(f.get('glosa')), 2), 'sit': txt(f.get('situacao')),
                   'liq': data(f.get('data_liquidacao'))} for f in d['faturas']]
    reg['res'] = [{'funcao': txt(r.get('funcao_id')),
                   'nome': mascara(re.sub(r'^[\d\*\.\-]+\s*-\s*', '', txt(r.get('usuario')))),
                   'portaria': txt(r.get('portaria')), 'sit': txt(r.get('situacao'))} for r in d['responsaveis']]
    reg['itn'] = [{'desc': txt(x.get('descricao_complementar') or x.get('catmatseritem_id'), 200), 'tipo': txt(x.get('tipo_id')),
                   'qtd': num(x.get('quantidade')), 'vUnit': num(x.get('valorunitario')), 'vTot': num(x.get('valortotal'))}
                  for x in d['itens']]
    reg['arq'] = [{'tipo': txt(a.get('tipo')), 'desc': txt(a.get('descricao'), 200), 'pdf': txt(a.get('path_arquivo')),
                   'sei': txt(a.get('link_sei'))} for a in d['arquivos']]
    return reg


def main():
    t0 = time.time()
    cfg = json.load(open(os.path.join(RAIZ, 'config', 'ugs.json'), encoding='utf-8'))
    ugs = list(dict.fromkeys(u['codigo'] for u in cfg['ugs']))   # sem repetição
    rotulos = {u['codigo']: u.get('rotulo', '') for u in cfg['ugs'] if u.get('rotulo')}

    brutos, vistos = [], set()
    for ug in ugs:
        for ativo, caminho in [(1, f'/api/contrato/ug/{ug}'), (0, f'/api/contrato/inativo/ug/{ug}')]:
            n = 0
            for c in lista(get(caminho)):
                if isinstance(c, dict) and c.get('id') not in vistos:
                    c['_ativo'], c['_ug'] = ativo, ug
                    brutos.append(c); vistos.add(c.get('id')); n += 1
            print(f'UG {ug} {"ativos" if ativo else "inativos"}: {n}', flush=True)

    ativos = [c for c in brutos if c['_ativo']]
    with ThreadPoolExecutor(4) as ex:
        det = dict((c['id'], d) for c, d in ex.map(detalhes, ativos))

    contratos = [montar(c, det.get(c['id']), c['_ug'], rotulos) for c in brutos]
    contratos.sort(key=lambda r: (not r['ativo'], r['fim'] or '9999'))
    agora = datetime.now(BRT)
    saida = {
        'atualizado': agora.strftime('%d/%m/%Y %H:%M'),
        'fonte': 'Contratos.gov.br · API pública',
        'ugs': {u: next((r['ugNome'] for r in contratos if r['ug'] == u and r['ugNome']), rotulos.get(u, '')) for u in ugs},
        'contratos': contratos,
    }
    os.makedirs(OUT, exist_ok=True)
    with open(os.path.join(OUT, 'contratos.json'), 'w', encoding='utf-8') as fh:
        json.dump(saida, fh, ensure_ascii=False, separators=(',', ':'))
    print(f'Gravado: {len(contratos)} contratos ({len(ativos)} ativos) em {time.time() - t0:.0f}s', flush=True)


if __name__ == '__main__':
    try:
        main()
    except Exception as e:
        print(f'Contratos.gov.br falhou: {e}', flush=True)
        ant = os.path.join(ANT, 'contratos.json') if ANT else ''
        if ant and os.path.exists(ant) and os.path.getsize(ant) > 50:
            os.makedirs(OUT, exist_ok=True)
            shutil.copy(ant, os.path.join(OUT, 'contratos.json'))
            print('Mantido o arquivo da rodada anterior.', flush=True)
        else:
            sys.exit(1)
